import Loginfile from './Components/Login/Loginfile';
import Signup from './Components/Signup/Signup';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Navbar from './Components/Navbar/Navbar';
import Textform from './Components/Navbar/Textform';
import React,{useState} from 'react'
import Otplogin from './Components/Otplogin';
import Home from './Components/Dashboard/Home';

function App() {
  const [mode, setmode] = useState('light');
  const [btntext, setbtntext] =useState('Enable Dark Mode');

  const togglemode=()=>{
    if(mode === 'light'){
      setmode('dark');
      setbtntext('Enable Light Mode');
      document.body.style.backgroundColor='rgb(0 12 24)';
      document.body.style.color="white";
    }
    else{
      setmode('light');
      setbtntext('Enable Dark Mode');
      document.body.style.backgroundColor='white';
      document.body.style.color="black";

    }
  }
  return (
    <>
      <Router>
        <Routes>
        <Route path='/' element={<Home />} />
          <Route path='/signup' element={<Signup />} />
          <Route path='/login' element={<Loginfile />} />
          <Route path='/otplogin' element={<Otplogin />} />
          <Route path='/navbar' element={<><Navbar mode={mode} togglemode={togglemode}  togglebtn={btntext}/><Textform headingtext="Enter your text below:" /></>} />
        </Routes>
      </Router>
    </>
  );

}


export default App;
